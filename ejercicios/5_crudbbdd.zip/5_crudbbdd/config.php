<?php

define("SQLITE", 2);
define("MYSQL", 1);

define("MENU_PRINCIPAL", 1);
define("MENU_VOLVER", 2);

$cfg["dbMotor"] = MYSQL;

$cfg["mysqlHost"] = "localhost";
$cfg["mysqlUser"] = "root";
$cfg["mysqlPassword"] = "";
$cfg["mysqlDatabase"] = "crudpersonas";

$cfg["nombretabla"] = "personas";