<footer>
    <p>&reg; Creado por: <strong>Alexa Milla Villavicencio</strong></p>
    <p>Asignatura: Desarrollo web entorno Servidor</p>
</footer>