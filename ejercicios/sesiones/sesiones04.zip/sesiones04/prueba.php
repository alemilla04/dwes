<?php
// print "<pre>";
// print_r($_COOKIE["Alexa"]);
// print "</pre>";

print "<pre>";
print_r($_FILES);
print "</pre>";